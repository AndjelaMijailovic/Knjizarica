$('#button').click(function(){
    alert('Hello');    
})