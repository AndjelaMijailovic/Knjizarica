<?php

    $sifra = $_GET['sifra'];
    header('Location: prijava.html');

?>