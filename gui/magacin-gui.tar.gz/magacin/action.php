<?php
	$sifra = $_GET['sifra'];
	$kolicina = $_GET['kolicina'];
	file_put_contents("tekst.txt",$sifra." ".$kolicina. PHP_EOL, FILE_APPEND);
	echo $sifraText;
	header('Location: primanje.html');
?>
