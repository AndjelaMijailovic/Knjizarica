<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Magacin</title>

    <link href="bootstrap.min.css" rel="stylesheet">
    <link href="magacin.css" rel="stylesheet">

  </head>

  <body class="bg">

    <nav class="navbar navbar-expand-lg nc fixed-top">
      <div class="container-fluid">
        <img src="logo.png" class="img-fluid" alt="Responsive image">

        <h3 class="col-lg-3 text-white">Knjižarica</h3>

        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link text-white">Ime i prezime prijavljenog zaposlenog</a>
            </li>
            <li class="nav-item">
              <button class="btn btn-primary" type="button">Obaveštenja <span class="badge badge-light">1</span></button>
            </li>
            <li class="nav-item">
              <button class="btn btn-outline-light" type="submit">Odjavi se</button>              
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <ul class="nav nav-tabs mt-5">
      <li class="nav-item active">
        <a class="nav-link" href="#">Stanje magacina</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="primanje.html">Primanje robe</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="dopremanje.html">Dopremanje robe</a>
      </li>
      
    </ul>

    <div class="tab-pane in active col-md-4 offset-md-1 mt-5">
     <table class="table table-striped table-bordered table-light">
        <tr>
            <td>Šifra</td>
            <td>Količina</td>
        </tr>
     <?php
        
        $lines = explode( PHP_EOL, file_get_contents("tekst.txt"));
        foreach($lines as $line ) {
            $words = explode(" ", $line);
              echo "<tr>";
            foreach($words as $word) {
            echo "<td>".$word.PHP_EOL."</td>";
           }
              echo "</tr>";      
        }
        
     
     ?>
     </table>
    </div>

  </body>

</html>
