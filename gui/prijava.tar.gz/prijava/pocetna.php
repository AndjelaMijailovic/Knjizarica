<?php
	$n = $_GET[username];
	$p = $_GET[password];
	
	switch ($n[0]) {
		case 'z':
			header('Location: ../kasa/kasa.html');
			break;
			
		case "m":
			header('Location: ../magacin/stanje.php');
			break;
		
		case 's':
			header('Location: ../sef/sef.html');
			break;
		
		case 'o':
			header('Location: ../organizator/knjizevnoVece.html');
	}

?>
